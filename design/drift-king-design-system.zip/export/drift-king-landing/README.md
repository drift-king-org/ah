# Drift King landing page

Static HTML and CSS. Open `index.html` in a browser; nothing to build.

## Files
- `index.html`: the page. Class names follow Apricotter's x-* expander output (site-header, hero__box, column, section-divider, statement-card, statement-list, rule-list, media-split, cta-row, site-footer).
- `page.css`: every rule the page uses. Layout values are copied from Apricotter's `public/components/*.css`; colours, fonts and shadows are Drift King's.
- `styles.css`: the Drift King tokens entry point (`@import`s `tokens/`). Link it before `page.css`.
- `tokens/`: colour, type and spacing custom properties. `fonts.css` loads Bungee, Chakra Petch and JetBrains Mono from Google Fonts (substitutes; no brand font files were provided).
- `assets/`: favicon, kart cut-out (hero), full scene (closing section).

## To wire up
- Links point at `/intent/letter-of-intent` and `/console`. Change them if the routes differ.
- The tickers are filled by the inline script at the bottom of `index.html` (two word lists, `A` and `B`). The "Spot the drift" sample is the other script, inline at the bottom of `index.html`. It is demo content.
- The kart bob and the button press honour `prefers-reduced-motion`.
- If this becomes a Mustache template, the repeated blocks are `.statement-list__row`, `.rule-list__item` and `.ln`. The sample panel uses a container query, so keep `.artifact` as its own element.
