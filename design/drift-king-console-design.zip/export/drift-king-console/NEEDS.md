# Console: component needs

Each of these is something no x-* tag emits today. They're written generically, with no Drift King words. The class names in `console.css` marked NEED are stand-ins until a tag exists.

1. **Status label.** A written state with a shape marker beside it. It needs a variant per state, so the shape differs as well as the colour. Used for open and done.
2. **Progress meter.** A count of items met out of items, with one mark per item, filled when met. It wraps at any count. Both numbers are counted from a list of items.
3. **Checked list.** A list of quoted items. Each one shows either the thing that met it, as a link, or the words "not met yet". The marker is filled or hollow.
4. **Quote with source.** One sentence, set as a quote, with a link that opens the source on that sentence.
5. **Hash.** A full fingerprint in monospace that wraps, linked to the thing it fingerprints and labelled with its kind (sha256, commit).
6. **Toggle group.** Radio inputs shown as a row of buttons. It works with the keyboard and without script, and other parts of the page can react to it with CSS.
7. **Paired timeline.** Rows that each hold a left cell (an event) and a right cell (zero or more notes), side by side on desktop and interleaved on a phone. Each row is a link target, so selecting the event or a note selects the row, and both light up.
8. **Speech bubble.** A note with a tail pointing at the cell it's about, and a link back to it.

Two tags exist but `components/x.css` doesn't paint them yet: **x-terms** (`terms`, `terms__row`, `terms__term`, `terms__body`) and **x-tag** (`tag`). Their rules are at the top of `console.css` and belong in `x.css`.

## Data the builder needs to provide
- `asks_met` and `asks_total` per agreement, counted from `asks[]` and `fulfilled_by[]`. Mustache can't count.
- The position of each event in the run (`--i`), for the replay delay.
- The id of the next event, for "Next event".

## Not read, shown as dashed `{{field}}` boxes in `intents.html`
- The console agreement's `document.sha256`. Its `document.url` and `approval_page` follow the gap pages' pattern and weren't confirmed.
- The ship gap's `intent.quote` and `holding[]`. The check URL follows the linter's pattern.
- All 16 asks of "x-components: what good looks like, version 2", plus its document and signing.
- The directive gives that last row's kind as "list", which isn't one of the five kinds. It's shown as given.
